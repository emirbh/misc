package iso20022.auth030.mas.meta;

import com.rosetta.model.lib.annotations.RosettaMeta;
import com.rosetta.model.lib.meta.RosettaMetaData;
import com.rosetta.model.lib.qualify.QualifyFunctionFactory;
import com.rosetta.model.lib.qualify.QualifyResult;
import com.rosetta.model.lib.validation.Validator;
import com.rosetta.model.lib.validation.ValidatorFactory;
import com.rosetta.model.lib.validation.ValidatorWithArg;
import iso20022.auth030.mas.TradeTransaction50__7;
import iso20022.auth030.mas.validation.TradeTransaction50__7TypeFormatValidator;
import iso20022.auth030.mas.validation.TradeTransaction50__7Validator;
import iso20022.auth030.mas.validation.exists.TradeTransaction50__7OnlyExistsValidator;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.function.Function;


/**
 * @version ${project.version}
 */
@RosettaMeta(model=TradeTransaction50__7.class)
public class TradeTransaction50__7Meta implements RosettaMetaData<TradeTransaction50__7> {

	@Override
	public List<Validator<? super TradeTransaction50__7>> dataRules(ValidatorFactory factory) {
		return Arrays.asList(
		);
	}
	
	@Override
	public List<Function<? super TradeTransaction50__7, QualifyResult>> getQualifyFunctions(QualifyFunctionFactory factory) {
		return Collections.emptyList();
	}
	
	@Override
	public Validator<? super TradeTransaction50__7> validator(ValidatorFactory factory) {
		return factory.<TradeTransaction50__7>create(TradeTransaction50__7Validator.class);
	}

	@Override
	public Validator<? super TradeTransaction50__7> typeFormatValidator(ValidatorFactory factory) {
		return factory.<TradeTransaction50__7>create(TradeTransaction50__7TypeFormatValidator.class);
	}

	@Deprecated
	@Override
	public Validator<? super TradeTransaction50__7> validator() {
		return new TradeTransaction50__7Validator();
	}

	@Deprecated
	@Override
	public Validator<? super TradeTransaction50__7> typeFormatValidator() {
		return new TradeTransaction50__7TypeFormatValidator();
	}
	
	@Override
	public ValidatorWithArg<? super TradeTransaction50__7, Set<String>> onlyExistsValidator() {
		return new TradeTransaction50__7OnlyExistsValidator();
	}
}
