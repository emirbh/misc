package iso20022.auth030.asic;

import com.google.common.collect.ImmutableList;
import com.rosetta.model.lib.RosettaModelObject;
import com.rosetta.model.lib.RosettaModelObjectBuilder;
import com.rosetta.model.lib.annotations.Accessor;
import com.rosetta.model.lib.annotations.AccessorType;
import com.rosetta.model.lib.annotations.Multi;
import com.rosetta.model.lib.annotations.Required;
import com.rosetta.model.lib.annotations.RosettaAttribute;
import com.rosetta.model.lib.annotations.RosettaDataType;
import com.rosetta.model.lib.annotations.RuneAttribute;
import com.rosetta.model.lib.annotations.RuneDataType;
import com.rosetta.model.lib.meta.RosettaMetaData;
import com.rosetta.model.lib.path.RosettaPath;
import com.rosetta.model.lib.process.BuilderMerger;
import com.rosetta.model.lib.process.BuilderProcessor;
import com.rosetta.model.lib.process.Processor;
import com.rosetta.util.ListEquals;
import iso20022.auth030.asic.meta.NotionalAmount5__1Meta;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import static java.util.Optional.ofNullable;

/**
 * @version ${project.version}
 */
@RosettaDataType(value="NotionalAmount5__1", builder=NotionalAmount5__1.NotionalAmount5__1BuilderImpl.class, version="${project.version}")
@RuneDataType(value="NotionalAmount5__1", model="iso20022", builder=NotionalAmount5__1.NotionalAmount5__1BuilderImpl.class, version="${project.version}")
public interface NotionalAmount5__1 extends RosettaModelObject {

	NotionalAmount5__1Meta metaData = new NotionalAmount5__1Meta();

	/*********************** Getter Methods  ***********************/
	AmountAndDirection106__2 getAmt();
	List<? extends Schedule11__1> getSchdlPrd();

	/*********************** Build Methods  ***********************/
	NotionalAmount5__1 build();
	
	NotionalAmount5__1.NotionalAmount5__1Builder toBuilder();
	
	static NotionalAmount5__1.NotionalAmount5__1Builder builder() {
		return new NotionalAmount5__1.NotionalAmount5__1BuilderImpl();
	}

	/*********************** Utility Methods  ***********************/
	@Override
	default RosettaMetaData<? extends NotionalAmount5__1> metaData() {
		return metaData;
	}
	
	@Override
	@RuneAttribute("@type")
	default Class<? extends NotionalAmount5__1> getType() {
		return NotionalAmount5__1.class;
	}
	
	@Override
	default void process(RosettaPath path, Processor processor) {
		processRosetta(path.newSubPath("amt"), processor, AmountAndDirection106__2.class, getAmt());
		processRosetta(path.newSubPath("schdlPrd"), processor, Schedule11__1.class, getSchdlPrd());
	}
	

	/*********************** Builder Interface  ***********************/
	interface NotionalAmount5__1Builder extends NotionalAmount5__1, RosettaModelObjectBuilder {
		AmountAndDirection106__2.AmountAndDirection106__2Builder getOrCreateAmt();
		@Override
		AmountAndDirection106__2.AmountAndDirection106__2Builder getAmt();
		Schedule11__1.Schedule11__1Builder getOrCreateSchdlPrd(int index);
		@Override
		List<? extends Schedule11__1.Schedule11__1Builder> getSchdlPrd();
		NotionalAmount5__1.NotionalAmount5__1Builder setAmt(AmountAndDirection106__2 amt);
		NotionalAmount5__1.NotionalAmount5__1Builder addSchdlPrd(Schedule11__1 schdlPrd);
		NotionalAmount5__1.NotionalAmount5__1Builder addSchdlPrd(Schedule11__1 schdlPrd, int idx);
		NotionalAmount5__1.NotionalAmount5__1Builder addSchdlPrd(List<? extends Schedule11__1> schdlPrd);
		NotionalAmount5__1.NotionalAmount5__1Builder setSchdlPrd(List<? extends Schedule11__1> schdlPrd);

		@Override
		default void process(RosettaPath path, BuilderProcessor processor) {
			processRosetta(path.newSubPath("amt"), processor, AmountAndDirection106__2.AmountAndDirection106__2Builder.class, getAmt());
			processRosetta(path.newSubPath("schdlPrd"), processor, Schedule11__1.Schedule11__1Builder.class, getSchdlPrd());
		}
		

		NotionalAmount5__1.NotionalAmount5__1Builder prune();
	}

	/*********************** Immutable Implementation of NotionalAmount5__1  ***********************/
	class NotionalAmount5__1Impl implements NotionalAmount5__1 {
		private final AmountAndDirection106__2 amt;
		private final List<? extends Schedule11__1> schdlPrd;
		
		protected NotionalAmount5__1Impl(NotionalAmount5__1.NotionalAmount5__1Builder builder) {
			this.amt = ofNullable(builder.getAmt()).map(f->f.build()).orElse(null);
			this.schdlPrd = ofNullable(builder.getSchdlPrd()).filter(_l->!_l.isEmpty()).map(list -> list.stream().filter(Objects::nonNull).map(f->f.build()).filter(Objects::nonNull).collect(ImmutableList.toImmutableList())).orElse(null);
		}
		
		@Override
		@RosettaAttribute("amt")
		@Accessor(AccessorType.GETTER)
		@Required
		@RuneAttribute("amt")
		public AmountAndDirection106__2 getAmt() {
			return amt;
		}
		
		@Override
		@RosettaAttribute("schdlPrd")
		@Accessor(AccessorType.GETTER)
		@Multi
		@RuneAttribute("schdlPrd")
		public List<? extends Schedule11__1> getSchdlPrd() {
			return schdlPrd;
		}
		
		@Override
		public NotionalAmount5__1 build() {
			return this;
		}
		
		@Override
		public NotionalAmount5__1.NotionalAmount5__1Builder toBuilder() {
			NotionalAmount5__1.NotionalAmount5__1Builder builder = builder();
			setBuilderFields(builder);
			return builder;
		}
		
		protected void setBuilderFields(NotionalAmount5__1.NotionalAmount5__1Builder builder) {
			ofNullable(getAmt()).ifPresent(builder::setAmt);
			ofNullable(getSchdlPrd()).ifPresent(builder::setSchdlPrd);
		}

		@Override
		public boolean equals(Object o) {
			if (this == o) return true;
			if (o == null || !(o instanceof RosettaModelObject) || !getType().equals(((RosettaModelObject)o).getType())) return false;
		
			NotionalAmount5__1 _that = getType().cast(o);
		
			if (!Objects.equals(amt, _that.getAmt())) return false;
			if (!ListEquals.listEquals(schdlPrd, _that.getSchdlPrd())) return false;
			return true;
		}
		
		@Override
		public int hashCode() {
			int _result = 0;
			_result = 31 * _result + (amt != null ? amt.hashCode() : 0);
			_result = 31 * _result + (schdlPrd != null ? schdlPrd.hashCode() : 0);
			return _result;
		}
		
		@Override
		public String toString() {
			return "NotionalAmount5__1 {" +
				"amt=" + this.amt + ", " +
				"schdlPrd=" + this.schdlPrd +
			'}';
		}
	}

	/*********************** Builder Implementation of NotionalAmount5__1  ***********************/
	class NotionalAmount5__1BuilderImpl implements NotionalAmount5__1.NotionalAmount5__1Builder {
	
		protected AmountAndDirection106__2.AmountAndDirection106__2Builder amt;
		protected List<Schedule11__1.Schedule11__1Builder> schdlPrd = new ArrayList<>();
		
		@Override
		@RosettaAttribute("amt")
		@Accessor(AccessorType.GETTER)
		@Required
		@RuneAttribute("amt")
		public AmountAndDirection106__2.AmountAndDirection106__2Builder getAmt() {
			return amt;
		}
		
		@Override
		public AmountAndDirection106__2.AmountAndDirection106__2Builder getOrCreateAmt() {
			AmountAndDirection106__2.AmountAndDirection106__2Builder result;
			if (amt!=null) {
				result = amt;
			}
			else {
				result = amt = AmountAndDirection106__2.builder();
			}
			
			return result;
		}
		
		@Override
		@RosettaAttribute("schdlPrd")
		@Accessor(AccessorType.GETTER)
		@Multi
		@RuneAttribute("schdlPrd")
		public List<? extends Schedule11__1.Schedule11__1Builder> getSchdlPrd() {
			return schdlPrd;
		}
		
		@Override
		public Schedule11__1.Schedule11__1Builder getOrCreateSchdlPrd(int index) {
			if (schdlPrd==null) {
				this.schdlPrd = new ArrayList<>();
			}
			return getIndex(schdlPrd, index, () -> {
						Schedule11__1.Schedule11__1Builder newSchdlPrd = Schedule11__1.builder();
						return newSchdlPrd;
					});
		}
		
		@RosettaAttribute("amt")
		@Accessor(AccessorType.SETTER)
		@Required
		@RuneAttribute("amt")
		@Override
		public NotionalAmount5__1.NotionalAmount5__1Builder setAmt(AmountAndDirection106__2 _amt) {
			this.amt = _amt == null ? null : _amt.toBuilder();
			return this;
		}
		
		@RosettaAttribute("schdlPrd")
		@Accessor(AccessorType.ADDER)
		@Multi
		@RuneAttribute("schdlPrd")
		@Override
		public NotionalAmount5__1.NotionalAmount5__1Builder addSchdlPrd(Schedule11__1 _schdlPrd) {
			if (_schdlPrd != null) {
				this.schdlPrd.add(_schdlPrd.toBuilder());
			}
			return this;
		}
		
		@Override
		public NotionalAmount5__1.NotionalAmount5__1Builder addSchdlPrd(Schedule11__1 _schdlPrd, int idx) {
			getIndex(this.schdlPrd, idx, () -> _schdlPrd.toBuilder());
			return this;
		}
		
		@Override
		public NotionalAmount5__1.NotionalAmount5__1Builder addSchdlPrd(List<? extends Schedule11__1> schdlPrds) {
			if (schdlPrds != null) {
				for (final Schedule11__1 toAdd : schdlPrds) {
					this.schdlPrd.add(toAdd.toBuilder());
				}
			}
			return this;
		}
		
		@RosettaAttribute("schdlPrd")
		@Accessor(AccessorType.SETTER)
		@Multi
		@RuneAttribute("schdlPrd")
		@Override
		public NotionalAmount5__1.NotionalAmount5__1Builder setSchdlPrd(List<? extends Schedule11__1> schdlPrds) {
			if (schdlPrds == null) {
				this.schdlPrd = new ArrayList<>();
			} else {
				this.schdlPrd = schdlPrds.stream()
					.map(_a->_a.toBuilder())
					.collect(Collectors.toCollection(()->new ArrayList<>()));
			}
			return this;
		}
		
		@Override
		public NotionalAmount5__1 build() {
			return new NotionalAmount5__1.NotionalAmount5__1Impl(this);
		}
		
		@Override
		public NotionalAmount5__1.NotionalAmount5__1Builder toBuilder() {
			return this;
		}
	
		@SuppressWarnings("unchecked")
		@Override
		public NotionalAmount5__1.NotionalAmount5__1Builder prune() {
			if (amt!=null && !amt.prune().hasData()) amt = null;
			schdlPrd = schdlPrd.stream().filter(b->b!=null).<Schedule11__1.Schedule11__1Builder>map(b->b.prune()).filter(b->b.hasData()).collect(Collectors.toList());
			return this;
		}
		
		@Override
		public boolean hasData() {
			if (getAmt()!=null && getAmt().hasData()) return true;
			if (getSchdlPrd()!=null && getSchdlPrd().stream().filter(Objects::nonNull).anyMatch(a->a.hasData())) return true;
			return false;
		}
	
		@SuppressWarnings("unchecked")
		@Override
		public NotionalAmount5__1.NotionalAmount5__1Builder merge(RosettaModelObjectBuilder other, BuilderMerger merger) {
			NotionalAmount5__1.NotionalAmount5__1Builder o = (NotionalAmount5__1.NotionalAmount5__1Builder) other;
			
			merger.mergeRosetta(getAmt(), o.getAmt(), this::setAmt);
			merger.mergeRosetta(getSchdlPrd(), o.getSchdlPrd(), this::getOrCreateSchdlPrd);
			
			return this;
		}
	
		@Override
		public boolean equals(Object o) {
			if (this == o) return true;
			if (o == null || !(o instanceof RosettaModelObject) || !getType().equals(((RosettaModelObject)o).getType())) return false;
		
			NotionalAmount5__1 _that = getType().cast(o);
		
			if (!Objects.equals(amt, _that.getAmt())) return false;
			if (!ListEquals.listEquals(schdlPrd, _that.getSchdlPrd())) return false;
			return true;
		}
		
		@Override
		public int hashCode() {
			int _result = 0;
			_result = 31 * _result + (amt != null ? amt.hashCode() : 0);
			_result = 31 * _result + (schdlPrd != null ? schdlPrd.hashCode() : 0);
			return _result;
		}
		
		@Override
		public String toString() {
			return "NotionalAmount5__1Builder {" +
				"amt=" + this.amt + ", " +
				"schdlPrd=" + this.schdlPrd +
			'}';
		}
	}
}
