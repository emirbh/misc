package iso20022.auth030.esma.validation.exists;

import com.google.common.collect.ImmutableMap;
import com.rosetta.model.lib.path.RosettaPath;
import com.rosetta.model.lib.validation.ExistenceChecker;
import com.rosetta.model.lib.validation.ValidationResult;
import com.rosetta.model.lib.validation.ValidatorWithArg;
import iso20022.auth030.esma.CommonTradeDataReport69__2;
import iso20022.auth030.esma.ContractType14__1;
import iso20022.auth030.esma.TradeTransaction49__2;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import static com.rosetta.model.lib.validation.ValidationResult.failure;
import static com.rosetta.model.lib.validation.ValidationResult.success;

public class CommonTradeDataReport69__2OnlyExistsValidator implements ValidatorWithArg<CommonTradeDataReport69__2, Set<String>> {

	/* Casting is required to ensure types are output to ensure recompilation in Rosetta */
	@Override
	public <T2 extends CommonTradeDataReport69__2> ValidationResult<CommonTradeDataReport69__2> validate(RosettaPath path, T2 o, Set<String> fields) {
		Map<String, Boolean> fieldExistenceMap = ImmutableMap.<String, Boolean>builder()
				.put("ctrctData", ExistenceChecker.isSet((ContractType14__1) o.getCtrctData()))
				.put("txData", ExistenceChecker.isSet((TradeTransaction49__2) o.getTxData()))
				.build();
		
		// Find the fields that are set
		Set<String> setFields = fieldExistenceMap.entrySet().stream()
				.filter(Map.Entry::getValue)
				.map(Map.Entry::getKey)
				.collect(Collectors.toSet());
		
		if (setFields.equals(fields)) {
			return success("CommonTradeDataReport69__2", ValidationResult.ValidationType.ONLY_EXISTS, "CommonTradeDataReport69__2", path, "");
		}
		return failure("CommonTradeDataReport69__2", ValidationResult.ValidationType.ONLY_EXISTS, "CommonTradeDataReport69__2", path, "",
				String.format("[%s] should only be set.  Set fields: %s", fields, setFields));
	}
}
