package iso20022.auth030.esma.validation.exists;

import com.google.common.collect.ImmutableMap;
import com.rosetta.model.lib.path.RosettaPath;
import com.rosetta.model.lib.validation.ExistenceChecker;
import com.rosetta.model.lib.validation.ValidationResult;
import com.rosetta.model.lib.validation.ValidatorWithArg;
import iso20022.auth030.esma.AssetClassProductType4Code;
import iso20022.auth030.esma.AssetClassSubProductType46Code;
import iso20022.auth030.esma.FreightCommodityContainerShip2;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import static com.rosetta.model.lib.validation.ValidationResult.failure;
import static com.rosetta.model.lib.validation.ValidationResult.success;

public class FreightCommodityContainerShip2OnlyExistsValidator implements ValidatorWithArg<FreightCommodityContainerShip2, Set<String>> {

	/* Casting is required to ensure types are output to ensure recompilation in Rosetta */
	@Override
	public <T2 extends FreightCommodityContainerShip2> ValidationResult<FreightCommodityContainerShip2> validate(RosettaPath path, T2 o, Set<String> fields) {
		Map<String, Boolean> fieldExistenceMap = ImmutableMap.<String, Boolean>builder()
				.put("basePdct", ExistenceChecker.isSet((AssetClassProductType4Code) o.getBasePdct()))
				.put("subPdct", ExistenceChecker.isSet((AssetClassSubProductType46Code) o.getSubPdct()))
				.build();
		
		// Find the fields that are set
		Set<String> setFields = fieldExistenceMap.entrySet().stream()
				.filter(Map.Entry::getValue)
				.map(Map.Entry::getKey)
				.collect(Collectors.toSet());
		
		if (setFields.equals(fields)) {
			return success("FreightCommodityContainerShip2", ValidationResult.ValidationType.ONLY_EXISTS, "FreightCommodityContainerShip2", path, "");
		}
		return failure("FreightCommodityContainerShip2", ValidationResult.ValidationType.ONLY_EXISTS, "FreightCommodityContainerShip2", path, "",
				String.format("[%s] should only be set.  Set fields: %s", fields, setFields));
	}
}
