package iso20022.auth030.esma.validation;

import com.google.common.collect.Lists;
import com.rosetta.model.lib.expression.ComparisonResult;
import com.rosetta.model.lib.path.RosettaPath;
import com.rosetta.model.lib.validation.ValidationResult;
import com.rosetta.model.lib.validation.Validator;
import iso20022.auth030.esma.PolypropyleneCommodityOther2;
import java.util.List;

import static com.google.common.base.Strings.isNullOrEmpty;
import static com.rosetta.model.lib.validation.ValidationResult.failure;
import static com.rosetta.model.lib.validation.ValidationResult.success;
import static java.util.stream.Collectors.toList;

public class PolypropyleneCommodityOther2TypeFormatValidator implements Validator<PolypropyleneCommodityOther2> {

	private List<ComparisonResult> getComparisonResults(PolypropyleneCommodityOther2 o) {
		return Lists.<ComparisonResult>newArrayList(
			);
	}

	@Override
	public List<ValidationResult<?>> getValidationResults(RosettaPath path, PolypropyleneCommodityOther2 o) {
		return getComparisonResults(o)
			.stream()
			.map(res -> {
				if (!isNullOrEmpty(res.getError())) {
					return failure("PolypropyleneCommodityOther2", ValidationResult.ValidationType.TYPE_FORMAT, "PolypropyleneCommodityOther2", path, "", res.getError());
				}
				return success("PolypropyleneCommodityOther2", ValidationResult.ValidationType.TYPE_FORMAT, "PolypropyleneCommodityOther2", path, "");
			})
			.collect(toList());
	}

}
