package iso20022.auth030.jfsa.validation;

import com.google.common.collect.Lists;
import com.rosetta.model.lib.expression.ComparisonResult;
import com.rosetta.model.lib.path.RosettaPath;
import com.rosetta.model.lib.validation.ValidationResult;
import com.rosetta.model.lib.validation.Validator;
import iso20022.auth030.jfsa.Frequency13Code__1;
import iso20022.auth030.jfsa.InterestRateContractTerm4__1;
import java.util.List;

import static com.google.common.base.Strings.isNullOrEmpty;
import static com.rosetta.model.lib.expression.ExpressionOperatorsNullSafe.checkCardinality;
import static com.rosetta.model.lib.validation.ValidationResult.failure;
import static com.rosetta.model.lib.validation.ValidationResult.success;
import static java.util.stream.Collectors.toList;

public class InterestRateContractTerm4__1Validator implements Validator<InterestRateContractTerm4__1> {

	private List<ComparisonResult> getComparisonResults(InterestRateContractTerm4__1 o) {
		return Lists.<ComparisonResult>newArrayList(
				checkCardinality("unit", (Frequency13Code__1) o.getUnit() != null ? 1 : 0, 0, 1), 
				checkCardinality("val", (Integer) o.getVal() != null ? 1 : 0, 0, 1)
			);
	}

	@Override
	public List<ValidationResult<?>> getValidationResults(RosettaPath path, InterestRateContractTerm4__1 o) {
		return getComparisonResults(o)
			.stream()
			.map(res -> {
				if (!isNullOrEmpty(res.getError())) {
					return failure("InterestRateContractTerm4__1", ValidationResult.ValidationType.CARDINALITY, "InterestRateContractTerm4__1", path, "", res.getError());
				}
				return success("InterestRateContractTerm4__1", ValidationResult.ValidationType.CARDINALITY, "InterestRateContractTerm4__1", path, "");
			})
			.collect(toList());
	}

}
