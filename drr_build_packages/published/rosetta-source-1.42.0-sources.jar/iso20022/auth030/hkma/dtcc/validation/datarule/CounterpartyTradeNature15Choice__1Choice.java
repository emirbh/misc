package iso20022.auth030.hkma.dtcc.validation.datarule;

import com.google.inject.ImplementedBy;
import com.rosetta.model.lib.annotations.RosettaDataRule;
import com.rosetta.model.lib.expression.ComparisonResult;
import com.rosetta.model.lib.mapper.MapperS;
import com.rosetta.model.lib.path.RosettaPath;
import com.rosetta.model.lib.validation.ChoiceRuleValidationMethod;
import com.rosetta.model.lib.validation.ValidationResult;
import com.rosetta.model.lib.validation.Validator;
import iso20022.auth030.hkma.dtcc.CounterpartyTradeNature15Choice__1;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static com.rosetta.model.lib.expression.ExpressionOperatorsNullSafe.*;

/**
 * @version ${project.version}
 */
@RosettaDataRule("CounterpartyTradeNature15Choice__1Choice")
@ImplementedBy(CounterpartyTradeNature15Choice__1Choice.Default.class)
public interface CounterpartyTradeNature15Choice__1Choice extends Validator<CounterpartyTradeNature15Choice__1> {
	
	String NAME = "CounterpartyTradeNature15Choice__1Choice";
	String DEFINITION = "one-of";
	
	class Default implements CounterpartyTradeNature15Choice__1Choice {
	
		@Override
		public List<ValidationResult<?>> getValidationResults(RosettaPath path, CounterpartyTradeNature15Choice__1 counterpartyTradeNature15Choice__1) {
			ComparisonResult result = executeDataRule(counterpartyTradeNature15Choice__1);
			if (result.getOrDefault(true)) {
				return Arrays.asList(ValidationResult.success(NAME, ValidationResult.ValidationType.DATA_RULE, "CounterpartyTradeNature15Choice__1", path, DEFINITION));
			}
			
			String failureMessage = result.getError();
			if (failureMessage == null || failureMessage.contains("Null") || failureMessage == "") {
				failureMessage = "Condition has failed.";
			}
			return Arrays.asList(ValidationResult.failure(NAME, ValidationResult.ValidationType.DATA_RULE, "CounterpartyTradeNature15Choice__1", path, DEFINITION, failureMessage));
		}
		
		private ComparisonResult executeDataRule(CounterpartyTradeNature15Choice__1 counterpartyTradeNature15Choice__1) {
			try {
				return choice(MapperS.of(counterpartyTradeNature15Choice__1), Arrays.asList("fi", "nfi", "cntrlCntrPty", "othr"), ChoiceRuleValidationMethod.REQUIRED);
			}
			catch (Exception ex) {
				return ComparisonResult.failure(ex.getMessage());
			}
		}
	}
	
	@SuppressWarnings("unused")
	class NoOp implements CounterpartyTradeNature15Choice__1Choice {
	
		@Override
		public List<ValidationResult<?>> getValidationResults(RosettaPath path, CounterpartyTradeNature15Choice__1 counterpartyTradeNature15Choice__1) {
			return Collections.emptyList();
		}
	}
}
