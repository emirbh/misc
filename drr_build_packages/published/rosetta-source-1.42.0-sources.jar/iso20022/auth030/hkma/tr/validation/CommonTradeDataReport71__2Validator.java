package iso20022.auth030.hkma.tr.validation;

import com.google.common.collect.Lists;
import com.rosetta.model.lib.expression.ComparisonResult;
import com.rosetta.model.lib.path.RosettaPath;
import com.rosetta.model.lib.validation.ValidationResult;
import com.rosetta.model.lib.validation.Validator;
import iso20022.auth030.hkma.tr.CommonTradeDataReport71__2;
import iso20022.auth030.hkma.tr.ContractType15__1;
import iso20022.auth030.hkma.tr.TradeTransaction50__2;
import java.util.List;

import static com.google.common.base.Strings.isNullOrEmpty;
import static com.rosetta.model.lib.expression.ExpressionOperatorsNullSafe.checkCardinality;
import static com.rosetta.model.lib.validation.ValidationResult.failure;
import static com.rosetta.model.lib.validation.ValidationResult.success;
import static java.util.stream.Collectors.toList;

public class CommonTradeDataReport71__2Validator implements Validator<CommonTradeDataReport71__2> {

	private List<ComparisonResult> getComparisonResults(CommonTradeDataReport71__2 o) {
		return Lists.<ComparisonResult>newArrayList(
				checkCardinality("ctrctData", (ContractType15__1) o.getCtrctData() != null ? 1 : 0, 1, 1), 
				checkCardinality("txData", (TradeTransaction50__2) o.getTxData() != null ? 1 : 0, 1, 1)
			);
	}

	@Override
	public List<ValidationResult<?>> getValidationResults(RosettaPath path, CommonTradeDataReport71__2 o) {
		return getComparisonResults(o)
			.stream()
			.map(res -> {
				if (!isNullOrEmpty(res.getError())) {
					return failure("CommonTradeDataReport71__2", ValidationResult.ValidationType.CARDINALITY, "CommonTradeDataReport71__2", path, "", res.getError());
				}
				return success("CommonTradeDataReport71__2", ValidationResult.ValidationType.CARDINALITY, "CommonTradeDataReport71__2", path, "");
			})
			.collect(toList());
	}

}
